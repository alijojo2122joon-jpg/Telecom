# TelecomShield Mobile

A mobile-first telecom security and billing-integrity auditing foundation.

## Current version

v0.1

### Included

- Android project (Kotlin + Jetpack Compose, Material 3)
- Gradle wrapper (8.14.3) + GitHub Actions CI that builds a debug APK
- Local network interface discovery (read-only)
- IPv4 / IPv6 observation
- Interface detection (state, MTU, multicast)
- Security findings dashboard foundation
- Reports screen foundation

### Planned modules

- Network path analysis
- Evidence engine
- Billing integrity validation
- Before/after verification
- Evidence hashing
- PDF / JSON reports

## Build

### In the cloud (no PC needed)

Push this repo to GitHub, then open **Actions → Build Android APK → Run workflow**.
Download the `TelecomShieldMobile-debug` artifact when the run finishes.

### Locally

Open in Android Studio with JDK 17, or run:

    ./gradlew :app:assembleDebug

Targets Android 8.0+ (minSdk 26), compiles against Android 15 (API 35).

## Important

This project performs passive, read-only observation of the device's own
network interfaces. It does not implement a generic Internet bypass or a
free-Internet injector.
