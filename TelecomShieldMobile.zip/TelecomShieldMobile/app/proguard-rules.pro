# Keep default Android/Compose behavior. No custom rules needed for v0.1.
-dontwarn kotlinx.**
