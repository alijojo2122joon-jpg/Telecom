package com.telecomshield.mobile

import java.net.Inet4Address
import java.net.Inet6Address
import java.net.NetworkInterface

/**
 * Read-only, local observation of the device's own network interfaces.
 *
 * This inspects only what the OS already exposes about this device
 * (interface names, state, and assigned IP addresses). It performs no
 * scanning of other hosts and no traffic interception.
 */
data class InterfaceInfo(
    val name: String,
    val displayName: String,
    val isUp: Boolean,
    val isLoopback: Boolean,
    val supportsMulticast: Boolean,
    val mtu: Int,
    val ipv4: List<String>,
    val ipv6: List<String>
)

object NetworkInspector {

    fun listInterfaces(): List<InterfaceInfo> {
        val result = mutableListOf<InterfaceInfo>()
        val interfaces = try {
            NetworkInterface.getNetworkInterfaces()
        } catch (e: Exception) {
            null
        } ?: return emptyList()

        for (nif in interfaces) {
            val ipv4 = mutableListOf<String>()
            val ipv6 = mutableListOf<String>()

            for (addr in nif.inetAddresses) {
                when (addr) {
                    is Inet4Address -> addr.hostAddress?.let { ipv4.add(it) }
                    is Inet6Address -> {
                        val raw = addr.hostAddress ?: continue
                        // Strip the zone id (e.g. %wlan0) for readability.
                        ipv6.add(raw.substringBefore('%'))
                    }
                }
            }

            result.add(
                InterfaceInfo(
                    name = nif.name ?: "?",
                    displayName = runCatching { nif.displayName }.getOrNull() ?: (nif.name ?: "?"),
                    isUp = runCatching { nif.isUp }.getOrDefault(false),
                    isLoopback = runCatching { nif.isLoopback }.getOrDefault(false),
                    supportsMulticast = runCatching { nif.supportsMulticast() }.getOrDefault(false),
                    mtu = runCatching { nif.mtu }.getOrDefault(-1),
                    ipv4 = ipv4,
                    ipv6 = ipv6
                )
            )
        }

        return result.sortedWith(
            compareByDescending<InterfaceInfo> { it.isUp && !it.isLoopback }
                .thenBy { it.name }
        )
    }

    fun summarize(interfaces: List<InterfaceInfo>): NetworkSummary {
        val active = interfaces.filter { it.isUp && !it.isLoopback }
        return NetworkSummary(
            totalInterfaces = interfaces.size,
            activeInterfaces = active.size,
            ipv4Count = interfaces.sumOf { it.ipv4.size },
            ipv6Count = interfaces.sumOf { it.ipv6.size }
        )
    }
}

data class NetworkSummary(
    val totalInterfaces: Int,
    val activeInterfaces: Int,
    val ipv4Count: Int,
    val ipv6Count: Int
)
