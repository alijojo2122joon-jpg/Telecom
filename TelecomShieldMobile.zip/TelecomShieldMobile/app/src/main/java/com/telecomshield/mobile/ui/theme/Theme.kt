package com.telecomshield.mobile.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Accent = Color(0xFF0288D1)
private val AccentLight = Color(0xFF4FC3F7)

private val LightColors = lightColorScheme(
    primary = Accent,
    secondary = AccentLight,
)

private val DarkColors = darkColorScheme(
    primary = AccentLight,
    secondary = Accent,
)

@Composable
fun TelecomShieldTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        content = content
    )
}
