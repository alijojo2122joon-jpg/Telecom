package com.telecomshield.mobile

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Lan
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.telecomshield.mobile.ui.theme.TelecomShieldTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TelecomShieldTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppRoot()
                }
            }
        }
    }
}

private enum class Tab(val label: String, val icon: ImageVector) {
    Dashboard("Dashboard", Icons.Filled.Security),
    Network("Network", Icons.Filled.Lan),
    Reports("Reports", Icons.Filled.Assessment)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    var current by remember { mutableStateOf(Tab.Dashboard) }

    Scaffold(
        topBar = {
            TopAppBar(title = { Text("TelecomShield Mobile") })
        },
        bottomBar = {
            NavigationBar {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(
                        selected = current == tab,
                        onClick = { current = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.label) },
                        label = { Text(tab.label) }
                    )
                }
            }
        }
    ) { inner ->
        Column(modifier = Modifier.padding(inner)) {
            when (current) {
                Tab.Dashboard -> DashboardScreen()
                Tab.Network -> NetworkScreen()
                Tab.Reports -> ReportsScreen()
            }
        }
    }
}

@Composable
private fun SectionCard(
    title: String,
    content: @Composable () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                title,
                fontWeight = FontWeight.SemiBold,
                fontSize = 16.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

@Composable
private fun DashboardScreen() {
    val state by produceState(initialValue = NetworkSummary(0, 0, 0, 0)) {
        value = withContext(Dispatchers.IO) {
            NetworkInspector.summarize(NetworkInspector.listInterfaces())
        }
    }

    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(8.dp))
        SectionCard("Security status") {
            Text("Foundation build — passive, read-only observation only.")
            Spacer(Modifier.height(4.dp))
            Text(
                "No active validation modules are enabled in v0.1.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        SectionCard("Network snapshot") {
            MetricRow("Interfaces detected", state.totalInterfaces.toString())
            MetricRow("Active interfaces", state.activeInterfaces.toString())
            MetricRow("IPv4 addresses", state.ipv4Count.toString())
            MetricRow("IPv6 addresses", state.ipv6Count.toString())
        }
        SectionCard("Planned modules") {
            listOf(
                "Network path analysis",
                "Evidence engine",
                "Billing integrity validation",
                "Before/after verification",
                "Evidence hashing",
                "PDF / JSON reports"
            ).forEach {
                Text("•  $it", fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, fontSize = 14.sp)
        Text(value, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun NetworkScreen() {
    val interfaces by produceState(initialValue = emptyList<InterfaceInfo>()) {
        value = withContext(Dispatchers.IO) { NetworkInspector.listInterfaces() }
    }

    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(8.dp))
        if (interfaces.isEmpty()) {
            SectionCard("Interfaces") {
                Text("No interfaces reported by the system.")
            }
        } else {
            interfaces.forEach { nif ->
                SectionCard("${nif.name}  ${if (nif.isUp) "● up" else "○ down"}") {
                    Text(nif.displayName, fontSize = 13.sp)
                    Spacer(Modifier.height(6.dp))
                    MetricRow("Loopback", if (nif.isLoopback) "yes" else "no")
                    MetricRow("Multicast", if (nif.supportsMulticast) "yes" else "no")
                    MetricRow("MTU", if (nif.mtu >= 0) nif.mtu.toString() else "—")
                    if (nif.ipv4.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("IPv4", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        nif.ipv4.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 13.sp) }
                    }
                    if (nif.ipv6.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("IPv6", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        nif.ipv6.forEach { Text(it, fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
    }
}

@Composable
private fun ReportsScreen() {
    Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
        Spacer(Modifier.height(8.dp))
        SectionCard("Reports") {
            Text("Report generation is not available in this foundation build.")
            Spacer(Modifier.height(4.dp))
            Text(
                "Once the evidence engine lands, signed PDF/JSON reports will appear here.",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Spacer(Modifier.height(16.dp))
    }
}
